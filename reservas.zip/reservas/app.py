from flask import Flask, render_template, request, redirect, session, url_for
import mysql.connector

app = Flask(__name__)
app.secret_key = "clave_secreta"  # Necesaria para sesiones

# Conexión a MySQL
def get_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="reservas_db"
    )

@app.route("/")
def index():
    return render_template("index.html")

# -------------------------------------------
# LOGIN
# -------------------------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        db = get_db()
        cursor = db.cursor(dictionary=True)

        cursor.execute(
            "SELECT * FROM usuarios WHERE email=%s AND password=%s",
            (email, password)
        )

        user = cursor.fetchone()
        cursor.close()
        db.close()

        if not user:
            return render_template("login.html", error="Correo o contraseña incorrectos")

        # Guardar sesión
        session["usuario"] = user["email"]
        session["rol"] = user["rol"]

        return redirect(url_for("dashboard"))

    return render_template("login.html")


# -------------------------------------------
# DASHBOARD (fuera del login)
# -------------------------------------------
@app.route("/dashboard")
def dashboard():
    if "usuario" not in session:
        return redirect(url_for("login"))
    
    return render_template("dashboard.html", usuario=session["usuario"])


if __name__ == "__main__":
    app.run(debug=True)

